# QuantSignal

Private stock-research web app built with React and Vinext. Includes an interactive research desk, synthetic demos, deterministic quant signals, public insider records, and optional AI explanations.

## Connect providers

Set server runtime secrets `ALPHA_VANTAGE_API_KEY` and optionally `OPENAI_API_KEY`. `OPENAI_MODEL` defaults to `gpt-4.1-mini`. Never put keys in client source or chat. In Sites, configure environment variables via the native Site tools. Local development can use an ignored `.env` file with the same variables. Switch to Connected in the UI after configuration.

Alpha Vantage must support TIME_SERIES_DAILY_ADJUSTED (subscription may be required) and INSIDER_TRANSACTIONS. Provider rate limits apply: each research or chat request fetches both endpoints. The initial UI is always a synthetic demo, explicitly labelled. A failed live request preserves the prior displayed mode and reports the error; it does not substitute demo data silently.

## Quant method

A neutral 50 is adjusted by trend ±25, 20-session momentum ±20, simple 14-session RSI mean-reversion ±5, and 90-calendar-day coded insider flow ±10, clipped to 0–100. Equality contributes zero trend. BUY >=70; SHORT <=30; otherwise WATCH. Stale prices (>5 calendar days) or realized annualized volatility >80% force WATCH. Scores are directional heuristics, not probabilities. The model has not been backtested or calibrated.

Only explicit P/S transaction codes are eligible for insider scoring. Acquisition/disposal indicators cannot establish an open-market trade. If the provider omits transaction codes, the insider score remains neutral while records are displayed for manual review. Form 4 can be delayed, and transactions need footnote/context review. No access to nonpublic information is supported.

No execution, broker connection, short borrow check, earnings/news feed, portfolio suitability, or automated trading is implemented. Shorting has unlimited loss potential and additional fees/recall risk. This is research support.

## Development

`npm ci`, `npm run dev`, `npm run build`.
`node --test lib/quant.test.mjs` (Node 22+ with TypeScript stripping).
`npx tsc --noEmit`.

## References

- https://www.alphavantage.co/documentation/
- https://www.sec.gov/files/forms-3-4-5.pdf
- https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create

Live provider calls require the user's keys and were not verified during the initial demo build.

## Initial verification

Six quant tests pass, TypeScript check passes, production build passes, and five local API checks cover demo analysis, invalid symbols, missing market keys, chat fallback, and question length validation. The research chat was also exercised in the browser at a narrow viewport. Live credentials were not supplied, so real provider responses and AI generation remain unverified.

Private Site registration succeeded, but upload/publishing was blocked by automatic approval review of the source helper continuation. No hosted release was published. The local `Start.command` starts the existing installed app on this Mac; the source archive requires `npm ci` before first use.
