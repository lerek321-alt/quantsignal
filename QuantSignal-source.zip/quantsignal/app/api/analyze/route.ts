import {analyze,demoData, type Bar, type Insider} from '../../../lib/quant';
export async function POST(request:Request){
 try{
 const body=await request.json() as {symbol?:unknown;mode?:unknown};const symbol=String(body.symbol||'').toUpperCase();
 if(!/^[A-Z][A-Z0-9.-]{0,9}$/.test(symbol))return Response.json({error:'Enter a valid US stock ticker.'},{status:400});
 if(body.mode!=='live')return Response.json({...demoData(symbol),symbol,insiderStatus:'Synthetic example transactions'});
 const key=process.env.ALPHA_VANTAGE_API_KEY;
 if(!key)return Response.json({error:'Live data is not connected. Add ALPHA_VANTAGE_API_KEY as a server secret, or use Demo.'},{status:503});
 async function get(fn:string){const u=new URL('https://www.alphavantage.co/query');u.search=new URLSearchParams({function:fn,symbol,apikey:key!,outputsize:'compact'}).toString();const r=await fetch(u,{signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('Market provider unavailable.');const d:any=await r.json();if(d.Information||d.Note||d['Error Message'])throw new Error('Provider rejected the request. Check the ticker, API subscription and rate limit.');return d;}
 const [prices,insiderResult]=await Promise.allSettled([get('TIME_SERIES_DAILY_ADJUSTED'),get('INSIDER_TRANSACTIONS')]);
 if(prices.status==='rejected')throw prices.reason;
 const series=prices.value['Time Series (Daily)'];if(!series)throw new Error('No daily prices returned.');
 const bars:Bar[]=Object.entries(series).map(([date,row]:[string,any])=>({date,close:Number(row['5. adjusted close'])}));
 const raw=insiderResult.status==='fulfilled'&&Array.isArray(insiderResult.value.data)?insiderResult.value.data:null;
 const insiders:Insider[]=(raw||[]).map((r:any)=>({date:r.transaction_date,name:r.executive||'Reported insider',side:r.acquisition_or_disposal==='A'?'Acquisition':'Disposal',value:Number(r.shares)*Number(r.share_price),code:r.transaction_code}));
 const result=analyze(bars,insiders);
 return Response.json({...result,symbol,insiderStatus:raw?'Provider records; only explicit P/S codes affect score':'Insider provider unavailable; neutral contribution',fetchedAt:new Date().toISOString()});
 }catch(e){return Response.json({error:e instanceof Error?e.message:'Analysis failed.'},{status:502});}
}
