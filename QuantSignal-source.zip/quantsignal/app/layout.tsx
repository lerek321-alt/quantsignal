import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'QuantSignal — Research with an edge',description:'Explainable quantitative stock research and public insider disclosures.'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
