export type Bar = {date:string; close:number};
export type Insider = {date:string; name:string; side:string; value:number; code?:string};
const mean=(x:number[])=>x.reduce((a,b)=>a+b,0)/x.length;
export function analyze(bars:Bar[],insiders:Insider[],demo=false,now=Date.now()) {
 if(bars.length<60 || bars.some(b=>!Number.isFinite(b.close)||b.close<=0||!Number.isFinite(Date.parse(b.date)))) throw new Error('At least 60 valid daily prices are required.');
 const sorted=[...bars].sort((a,b)=>a.date.localeCompare(b.date));
 if(new Set(sorted.map(b=>b.date)).size!==sorted.length) throw new Error('Duplicate price dates.');
 const p=sorted.map(b=>b.close), last=p.at(-1)!, sma20=mean(p.slice(-20)),sma50=mean(p.slice(-50));
 const momentum=(last/p.at(-21)!-1)*100;
 const returns=p.slice(-21).slice(1).map((v,i)=>Math.log(v/p.slice(-21)[i]));
 const avg=mean(returns), vol=Math.sqrt(returns.reduce((s,r)=>s+(r-avg)**2,0)/(returns.length-1))*Math.sqrt(252)*100;
 const deltas=p.slice(-15).slice(1).map((v,i)=>v-p.slice(-15)[i]);
 const gain=mean(deltas.map(v=>Math.max(v,0))),loss=mean(deltas.map(v=>Math.max(-v,0)));
 const rsi=loss===0?(gain===0?50:100):100-100/(1+gain/loss);
 const recent=insiders.filter(i=>Number.isFinite(i.value)&&i.value>0&&Date.parse(i.date)<=now&&now-Date.parse(i.date)<=90*86400000);
 // Only explicit P/S codes qualify. Acquisition/disposal flags alone can include grants and exercises.
 const buys=recent.filter(i=>i.code==='P').reduce((s,i)=>s+i.value,0), sells=recent.filter(i=>i.code==='S').reduce((s,i)=>s+i.value,0);
 const insiderScore=buys+sells>0?(buys-sells)/(buys+sells)*10:0;
 const trend=Math.sign(last-sma50)*15+Math.sign(sma20-sma50)*10, mom=Math.max(-20,Math.min(20,momentum*2));
 const reversion=rsi>75?-5:rsi<25?5:0;
 const score=Math.round(Math.max(0,Math.min(100,50+trend+mom+reversion+insiderScore)));
 const age=(now-Date.parse(sorted.at(-1)!.date))/86400000, stale=age>5||age< -1;
 const signal=stale||vol>80?'WATCH':score>=70?'BUY':score<=30?'SHORT':'WATCH';
 return {bars:sorted,insiders:recent.slice(0,20),price:last,change:(last/p.at(-2)!-1)*100,sma20,sma50,momentum,vol,rsi,score,signal,stale,demo,asOf:sorted.at(-1)!.date,insiderScore,buys,sells,eligible:recent.filter(i=>i.code==='P'||i.code==='S').length, factors:[{name:'Trend alignment',value:trend,max:25},{name:'20-day momentum',value:mom,max:20},{name:'Mean reversion',value:reversion,max:5},{name:'Public insider flow',value:insiderScore,max:10}]};
}
export function demoData(symbol:string) {
 const seed=[...symbol].reduce((s,c)=>s+c.charCodeAt(0),0), bars:Bar[]=[];
 let price=80+seed%180;
 for(let i=0;i<100;i++){const date=new Date(Date.UTC(2026,4,20+i));if([0,6].includes(date.getUTCDay()))continue;price*=1+((seed%7)-2)*.001+Math.sin(i*1.7+seed)*.014;bars.push({date:date.toISOString().slice(0,10),close:price});}
 const end=Date.parse(bars.at(-1)!.date);
 return analyze(bars,[{date:bars.at(-4)!.date,name:'Example director',side:'Acquisition',value:240000,code:'P'},{date:bars.at(-8)!.date,name:'Example executive',side:'Disposal',value:85000,code:'S'}],true,end);
}
export type Analysis=ReturnType<typeof analyze>;
export function explain(a:Analysis,symbol:string,question:string) {
 const base=`${a.demo?'Illustrative demo — ':''}${symbol}: ${a.signal} research signal (${a.score}/100 directional score; not a probability). As of ${a.asOf}.`;
 if(/insider|filing/i.test(question))return `${base}\n\nThe 90-day sample contains ${a.eligible} transactions with explicit P/S codes eligible for scoring. Purchase value: $${a.buys.toLocaleString()}; sale value: $${a.sells.toLocaleString()}. Insider contribution: ${a.insiderScore.toFixed(1)} points. Acquisition/disposal flags alone are excluded because they can include grants and exercises. Verify transaction codes and footnotes in the original SEC filings; reporting is delayed and sales can have many motives.`;
 if(/risk|short|volatil/i.test(question))return `${base}\n\nAnnualized 20-day realized volatility is ${a.vol.toFixed(1)}%. Shorting can incur unlimited losses, borrow fees, recalls and squeeze risk. Borrow availability and earnings events are not checked. ${a.stale?'Prices are stale, so the signal is forced to WATCH.':'This is an unvalidated heuristic, with no claimed backtested return or win rate.'} No orders are placed.`;
 return `${base}\n\n20-day momentum is ${a.momentum.toFixed(2)}%. Price is ${a.price>a.sma50?'above':'below'} its 50-day average ($${a.sma50.toFixed(2)}); the 20-day average is $${a.sma20.toFixed(2)}. The simple 14-session RSI is ${a.rsi.toFixed(1)}, and annualized realized volatility is ${a.vol.toFixed(1)}%.\n\nThe score combines trend (±25), momentum (±20), mean reversion (±5), and verified transaction-code insider flow (±10), from a neutral 50. BUY ≥70; SHORT ≤30; otherwise WATCH. Stale prices or volatility above 80% force WATCH. These thresholds have not been backtested. ${a.demo?'All prices and transactions shown are synthetic, not evidence about this company.':'Insider records are provider-supplied disclosures; check original filings.'}`;
}
