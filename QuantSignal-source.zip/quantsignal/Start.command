#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v node >/dev/null 2>&1; then
  quant_node="$(command -v node)"
else
  quant_node="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
fi
if [ ! -x "$quant_node" ]; then
  echo 'Install Node.js 22 or later, then run npm ci and npm run dev in this folder.'
  exit 1
fi
if [ ! -d node_modules/vinext ]; then
  echo 'Dependencies are not installed. Run npm ci in this folder first.'
  exit 1
fi
export PATH="$(dirname "$quant_node"):$PATH"
exec "$quant_node" scripts/run-framework.mjs dev
